<!doctype html>
<head>
	<meta charset="UTF-8">
	<title>예매확인</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" ></script>
	<div id="board_area">
		<?php
		//// mariadb 연결을 위한 (ip주소,계정명,비밀번호,db명) 입력으로 접속
		$conn = mysqli_connect("192.168.1.129","root","","freezia");
		$search_name=$_GET['name'];
		$search_mobile=$_GET['mobile'];
		
		//티켓이 이름과 전화번호가 각각 티켓 a,b,c와 같을때의 sql 지정
		$sql = "SELECT * FROM restbl where name='$search_name' && mobile='$search_mobile";
		$sql_a = "SELECT  name,mobile,ticket FROM restbl where name='$search_name' and mobile='$search_mobile' and ticket='a'";
		$sql_b = "SELECT  name,mobile,ticket FROM restbl where name='$search_name' and mobile='$search_mobile' and ticket='b'";
		$sql_c = "SELECT  name,mobile,ticket FROM restbl where name='$search_name' and mobile='$search_mobile' and ticket='c'";
		
		//$conn을 통해 연결한 객체를 통해 select하는 $sql_abc을 실행
		$result = mysqli_query($conn, $sql);
		$result_a = mysqli_query($conn, $sql_a);
		$result_b = mysqli_query($conn, $sql_b);
		$result_c = mysqli_query($conn, $sql_c);
		
 		//mysqli_query를 통해 select로 얻은 name,mobile,ticket에서 원하는것을 한개씩 리턴 받는다.
		$row_a = mysqli_fetch_assoc($result_a);
		$row_b = mysqli_fetch_assoc($result_b);
		$row_c = mysqli_fetch_assoc($result_c);
		
		//mysqli_query를 통해 select로 얻은 name,mobile,ticket에서 원하는 값의 개수를 받는다.
		$count_a = mysqli_num_rows($result_a);
		$count_b = mysqli_num_rows($result_b);
		$count_c = mysqli_num_rows($result_c);
		
		//DB접속 해제
		mysqli_close($conn);
		?>
	</div>
	<div class="container bcontent"><hr />
		<div class="card" style="width: 1230px;">
			<div class="row no-gutters">
				<div class="col-sm-7">
					<div class="card-body">
						<h1 class="card-title">예매자 정보</h1><br>
						<div class="form-floating mb-3">
							<?php
							if ($count_a != 0 )
							{
								echo "이름: <b>" . $row_a["name"] . "</b> , 핸드폰 번호: <b>" . $row_a["mobile"] . "</b> 님은 <b>뮤지컬 지킬앤하이드</b> 를  <b>".$count_a."</b>장 예매하셨습니다.<br>";
							}
							if ($count_b != 0 )
							{
								echo "이름: <b>". $row_b["name"] . "</b> , 핸드폰 번호: <b>" . $row_b["mobile"] . "</b> 님은 <b>뮤지컬 라이온 킹</b> 을   <b>".$count_b."</b>장 예매하셨습니다.<br>";
							}
							if ($count_c != 0 )
							{
								echo "이름: <b>" . $row_c["name"] . "</b> , 핸드폰 번호: <b>" . $row_c["mobile"] . "</b> 님은 <b>뮤지컬 데스노트</b> 를 <b>".$count_c."</b>장 예매하셨습니다.<br>";
							}
							if (($count_a == 0) and ($count_b == 0) and ($count_c == 0) )
							{
								echo '예매자 정보를 다시 확인해 주세요.';
							}
							?>
							<p><br><a class="btn btn-primary" href="search.php" role="button" >검색하기</a>
								<a class="btn btn-primary" href="index.html" role="button" >메인화면으로</a></p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>	