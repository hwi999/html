<!doctype html>
<head>
	<meta charset="UTF-8">
	<title>예매실패</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" ></script>
	
	<div class="container bcontent"><hr />
	<div class="card" style="width: 1200px;">
		<div class="row no-gutters">
			<div class="col-sm-7">
				<div class="card-body">
					<h1 class="card-title">예매시간만료</h1><br>
					<div class="form-floating mb-3">
						<br><a class="btn btn-primary" href="index.html" role="button" >메인화면으로</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</body>
